# HTML, CSS e JavaScript para iniciantes
Demonstração: https://html-css-javascript-iniciantes.vercel.app  
GitHub: https://github.com/artneo7/html-css-javascript-iniciantes  
Assets: https://github.com/artneo7/html-css-javascript-iniciantes-assets

## Recursos utilizados no projeto
Svelte: https://svelte.dev  
SvelteKit: https://kit.svelte.dev  
Design Figma: https://www.figma.com/community/file/1295819822468392257/html-css-e-javascript-para-iniciantes  
VS Code: https://code.visualstudio.com  
CodePen: https://codepen.io/artneo/pen/poqXyqL  
Vercel: https://vercel.com  
Fonte: https://fonts.google.com/specimen/Open+Sans  
Imagem: https://www.pexels.com/photo/smiling-man-in-a-gray-suit-standing-with-arms-crossed-by-a-fence-13801614  